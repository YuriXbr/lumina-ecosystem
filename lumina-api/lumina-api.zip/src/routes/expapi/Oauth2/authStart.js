const crypto = require('node:crypto');
const { getProvider } = require('../../../oauthProviders');
const { isAllowedOrigin, signState } = require('../../../oauthProviders/state');

/**
 * Inicia o login/cadastro automático via OAuth2 — NÃO exige conta ou JWT
 * prévios. Funciona para qualquer provider registrado em src/oauthProviders.
 *
 * Ex: GET /expapi/oauth2/discord/auth/start?origin=https://bot.luminasink.com
 *
 * Para suportar outro provedor (Google, GitHub...), basta o front chamar
 * a mesma rota trocando o :provider — nada aqui precisa mudar.
 */
module.exports = {
    route: '/expapi/oauth2/:provider/auth/start',
    description: 'Inicia login/cadastro via OAuth2 (sem necessidade de conta prévia)',
    apiKeyNeeded: false,
    internalKeyNeeded: false,
    jwtNeeded: false,
    enabled: true,
    loginLimiterNeeded: true,
    csrfProtectionNeeded: false,
    checkAuthNeeded: false,
    method: 'get',

    async execute(req, res) {
        const origin = req.query.origin || 'https://bot.luminasink.com';

        if (!isAllowedOrigin(origin)) {
            return res.status(400).json({ error: 'Origin não permitida.', code: 'INVALID_ORIGIN' });
        }

        let provider;
        try {
            provider = getProvider(req.params.provider);
        } catch {
            return res.status(404).json({ error: 'Provedor OAuth2 não suportado.', code: 'UNKNOWN_PROVIDER' });
        }

        const state = signState({
            origin,
            nonce: crypto.randomUUID(),
            issuedAt: Date.now()
        });

        return res.redirect(provider.getAuthorizationUrl(state));
    }
};
