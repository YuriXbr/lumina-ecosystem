import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../../contexts/UserContext";

/**
 * Página de destino do fluxo de login/cadastro via OAuth2.
 * O backend (src/routes/oauth/authCallback.js) redireciona para
 * `${origin}/oauth/complete#token=...&isNewAccount=...&hasPassword=...`.
 *
 * O token vem no FRAGMENTO (#), não na query string (?) — fragmentos nunca
 * são enviados ao servidor (não aparecem em logs de acesso, nem em Referer
 * headers de terceiros), o que é mais seguro do que mandar o JWT como `?token=`.
 *
 * Lembre-se de registrar esta rota no seu roteador, por exemplo:
 *   <Route path="/oauth/complete" element={<OAuthCompletePage />} />
 */
export default function OAuthCompletePage() {
    const navigate = useNavigate();
    const { onLoginSuccess } = useUser();
    const [error, setError] = useState("");

    useEffect(() => {
        const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
        const queryParams = new URLSearchParams(window.location.search);

        const token = hashParams.get("token");
        const isNewAccount = hashParams.get("isNewAccount") === "true";
        const hasPassword = hashParams.get("hasPassword") === "true";
        const oauthError = queryParams.get("oauthError");

        // Limpa o token da URL imediatamente, antes de qualquer outra coisa —
        // não queremos que ele fique no histórico do navegador.
        window.history.replaceState(null, "", window.location.pathname);

        if (oauthError) {
            setError("Não foi possível completar o login com o provedor selecionado. Tente novamente.");
            return;
        }

        if (!token) {
            setError("Token de autenticação não encontrado. Tente fazer login novamente.");
            return;
        }

        (async () => {
            localStorage.setItem("token", token);
            await onLoginSuccess();

            if (isNewAccount || !hasPassword) {
                // Conta nova (ou sem senha ainda) — leva pro fluxo de definir senha.
                navigate("/dashboard/settings?setupPassword=1", { replace: true });
            } else {
                navigate("/dashboard", { replace: true });
            }
        })();
    }, [navigate, onLoginSuccess]);

    if (error) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-violet-600/50 px-4">
                <div className="bg-gray-100 shadow-lg rounded-lg p-8 max-w-md text-center">
                    <p className="text-gray-800 mb-4">{error}</p>
                    <a href="/login" className="font-medium text-indigo-600 hover:text-indigo-500">
                        Voltar para o login
                    </a>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-violet-600/50">
            <div className="flex items-center gap-3 text-white">
                <svg className="animate-spin h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span className="text-lg">Concluindo login...</span>
            </div>
        </div>
    );
}
