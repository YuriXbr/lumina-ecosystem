const jwt = require('jsonwebtoken');
const { getProvider } = require('../../../oauthProviders');
const { isAllowedOrigin, verifyState } = require('../../../oauthProviders/state');
const DashboardAccountService = require('../../../database/services/DashboardAccountService');

const STATE_MAX_AGE_MS = 10 * 60 * 1000; // 10 minutos

/**
 * Callback chamado pelo provedor OAuth2 (Discord, etc.) após o usuário
 * autorizar. Resolve a conta (existente ou nova, sem senha) e entrega um JWT
 * de volta ao frontend via fragmento da URL (#token=...), que nunca é
 * enviado ao servidor nem fica em logs de acesso.
 */
module.exports = {
    route: '/expapi/oauth2/:provider/auth/callback',
    description: 'Callback OAuth2 — cria ou autentica conta automaticamente',
    apiKeyNeeded: false,
    internalKeyNeeded: false,
    jwtNeeded: false,
    enabled: true,
    loginLimiterNeeded: false,
    csrfProtectionNeeded: false,
    checkAuthNeeded: false,
    method: 'get',

    async execute(req, res) {
        let provider;
        try {
            provider = getProvider(req.params.provider);
        } catch {
            return res.status(404).send('Provedor OAuth2 não suportado.');
        }

        const { code, state: rawState, error } = req.query;
        const state = verifyState(rawState);

        if (!state || Date.now() - state.issuedAt > STATE_MAX_AGE_MS) {
            return res.status(400).send('Estado inválido ou expirado. Tente novamente.');
        }
        if (!isAllowedOrigin(state.origin)) {
            return res.status(400).send('Origin não permitida.');
        }
        if (!code || error) {
            return res.redirect(`${state.origin}/login?oauthError=${encodeURIComponent(error || 'missing_code')}`);
        }

        try {
            const tokens = await provider.exchangeCode(code);
            const profile = await provider.getProfile(tokens.accessToken);

            if (!profile.providerId) {
                throw new Error('Perfil OAuth2 retornado sem ID.');
            }

            // 1) Já existe conta vinculada a esse provider + providerId?
            let account = await DashboardAccountService.getDashboardAccountByProviderId(
                provider.name,
                profile.providerId
            );

            // 2) Senão, existe conta com o mesmo e-mail (verificado pelo provedor)
            //    para vincular automaticamente, evitando duplicar contas?
            if (!account && profile.email && profile.emailVerified) {
                account = await DashboardAccountService.getDashboardAccountByEmail(profile.email).catch(() => null);
                if (account) {
                    await DashboardAccountService.linkOAuthProvider(account.accountId, provider.name, {
                        providerId: profile.providerId,
                        linkedAt: new Date()
                    });
                }
            }

            // 3) Senão, cria uma conta nova SEM senha
            let isNewAccount = false;
            if (!account) {
                const [firstName, ...rest] = (profile.username || 'Usuário').split(' ');
                account = await DashboardAccountService.createOAuthAccount({
                    email: profile.email || `${provider.name}-${profile.providerId}@no-email.luminasink.com`,
                    firstName: firstName || 'Usuário',
                    lastName: rest.join(' ') || provider.name,
                    emailVerified: !!profile.emailVerified,
                    provider: provider.name,
                    providerId: profile.providerId,
                    registrationIp: req.ip,
                    registrationUserAgent: req.headers['user-agent'],
                    registrationCountry: req.headers['cf-ipcountry'] || ''
                });
                isNewAccount = true;
            }

            // Compatibilidade: contas via Discord também alimentam os campos
            // legados (discordOauth2Id/Token/...) já usados pelo resto do
            // sistema (inventário, bot, etc.), sem precisar "vincular" de novo.
            if (provider.name === 'discord') {
                await DashboardAccountService.update(
                    { accountId: account.accountId },
                    {
                        $set: {
                            discordOauth2Id: profile.providerId,
                            discordOauth2Token: tokens.accessToken,
                            discordOauth2RefreshToken: tokens.refreshToken,
                            discordOauth2TokenExpiresAt: new Date(Date.now() + tokens.expiresIn * 1000),
                            discordOauth2TokenScope: tokens.scope,
                            discordOauth2TokenType: tokens.tokenType,
                            discordOauth2TokenRequestDate: new Date(),
                            discordOauth2TokenRequestIp: req.ip
                        }
                    }
                );
            }

            const jwtToken = jwt.sign(
                {
                    email: account.email,
                    accountId: account.accountId,
                    firstName: account.firstName,
                    lastName: account.lastName
                },
                process.env.JWT_SECRET,
                { expiresIn: '1h' }
            );

            // hasPassword diz ao frontend se deve oferecer a tela de "definir senha"
            const hasPassword = !!account.password;

            const redirectUrl = new URL(`${state.origin}/oauth/complete`);
            redirectUrl.hash = `token=${jwtToken}&isNewAccount=${isNewAccount}&hasPassword=${hasPassword}`;

            return res.redirect(redirectUrl.toString());
        } catch (err) {
            console.error(`Erro no callback OAuth2 (${req.params.provider}):`, err);
            return res.redirect(`${state.origin}/login?oauthError=server_error`);
        }
    }
};
